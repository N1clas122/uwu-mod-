package com.example.client

import net.fabricmc.api.ClientModInitializer

object UwuModClient : ClientModInitializer {
	override fun onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}